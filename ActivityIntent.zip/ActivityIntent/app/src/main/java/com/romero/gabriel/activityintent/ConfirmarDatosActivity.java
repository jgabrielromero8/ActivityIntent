package com.romero.gabriel.activityintent;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class ConfirmarDatosActivity extends AppCompatActivity {

    private TextView tvNombre;
    private TextView tvParamFechaNacimiento;
    private TextView tvParamTelefono;
    private TextView tvParamCorreo;
    private TextView tvParamDescripcion;
    private Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmar_datos);

        tvNombre               = (TextView) findViewById(R.id.tvNombre);
        tvParamFechaNacimiento = (TextView) findViewById(R.id.tvParamFechaNacimiento);
        tvParamTelefono        = (TextView) findViewById(R.id.tvParamTelefono);
        tvParamCorreo          = (TextView) findViewById(R.id.tvParamCorreo);
        tvParamDescripcion     = (TextView) findViewById(R.id.tvParamDescripcion);

        //Parámetros
        bundle = getIntent().getExtras();

        String nombre       = bundle.get(getResources().getString(R.string.string_nombreCompleto)).toString();
        String fecha        = bundle.get(getResources().getString(R.string.string_fechaNacimiento)).toString();
        String telefono     = bundle.get(getResources().getString(R.string.string_telefono)).toString();
        String correo       = bundle.get(getResources().getString(R.string.string_correo)).toString();
        String descripcion  = bundle.get(getResources().getString(R.string.string_descripcionContacto)).toString();

        tvNombre.setText(nombre);
        tvParamFechaNacimiento.setText(fecha);
        tvParamTelefono.setText(telefono);
        tvParamCorreo.setText(correo);
        tvParamDescripcion.setText(descripcion);
    }

    public void openMainActivity(View view){
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtras(bundle);
        startActivity(intent);
        finish();
    }
}

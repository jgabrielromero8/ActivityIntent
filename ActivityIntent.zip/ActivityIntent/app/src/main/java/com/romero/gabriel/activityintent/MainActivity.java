package com.romero.gabriel.activityintent;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    TextInputEditText tietFechaNacimiento;
    TextInputEditText tietNombre;
    TextInputEditText tietTelefono;
    TextInputEditText tietEmail;
    TextInputEditText tietDescripcionContacto;
    private int mYear, mMonth, mDay;

    @Override
    protected void onCreate(Bundle savedInstanceState)  {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tietNombre                  = (TextInputEditText) findViewById(R.id.tietNombre);
        tietFechaNacimiento         = (TextInputEditText) findViewById(R.id.tietFechaNacimiento);
        tietTelefono                = (TextInputEditText) findViewById(R.id.tietTelefono);
        tietEmail                   = (TextInputEditText) findViewById(R.id.tietEmail);
        tietDescripcionContacto     = (TextInputEditText) findViewById(R.id.tietDescripcionContacto);

        existenParametros();
    }

    public void onClickDate(View v) {
        // Get Current Date
        final Calendar c = Calendar.getInstance();
        mYear = c.get(Calendar.YEAR);
        mMonth = c.get(Calendar.MONTH);
        mDay = c.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this, AlertDialog.THEME_HOLO_LIGHT,
                new DatePickerDialog.OnDateSetListener() {

                    @Override
                    public void onDateSet(DatePicker view, int year,
                                          int monthOfYear, int dayOfMonth) {

                        tietFechaNacimiento.setText(dayOfMonth + "-" + (monthOfYear + 1) + "-" + year);

                    }
                }, mYear, mMonth, mDay);
        datePickerDialog.setTitle(getResources().getText(R.string.string_fechaNacimiento));
        datePickerDialog.show();

    }

    //Método para abrir la actividad ConfirmarDatosActivity y enviar los parámetros del formulario
    public void openConfirmarDatos(View view){
        Intent intent = new Intent(this,ConfirmarDatosActivity.class);
        intent.putExtra(getResources().getString(R.string.string_nombreCompleto),tietNombre.getText());
        intent.putExtra(getResources().getString(R.string.string_fechaNacimiento),tietFechaNacimiento.getText());
        intent.putExtra(getResources().getString(R.string.string_telefono),tietTelefono.getText());
        intent.putExtra(getResources().getString(R.string.string_correo),tietEmail.getText());
        intent.putExtra(getResources().getString(R.string.string_descripcionContacto),tietDescripcionContacto.getText());
        startActivity(intent);
        finish();
    }

    //
    public void existenParametros(){
        Bundle bundle = getIntent().getExtras();

        if(bundle != null){
            String nombre      = bundle.get(getResources().getString(R.string.string_nombreCompleto)).toString();
            String fecha       = bundle.get(getResources().getString(R.string.string_fechaNacimiento)).toString();
            String telefono    = bundle.get(getResources().getString(R.string.string_telefono)).toString();
            String correo      = bundle.get(getResources().getString(R.string.string_correo)).toString();
            String descripcion = bundle.get(getResources().getString(R.string.string_descripcionContacto)).toString();

            tietNombre.setText(nombre);
            tietFechaNacimiento.setText(fecha);
            tietTelefono.setText(telefono);
            tietEmail.setText(correo);
            tietDescripcionContacto.setText(descripcion);
        }

    }

}
